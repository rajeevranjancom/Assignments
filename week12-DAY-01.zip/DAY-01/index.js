const [express, hbs, path, fs] = [
  require("express"),
  require("hbs"),
  require("path"),
  require("fs")
];

const registerroute = require(path.join(__dirname, 'routes', 'register'))


const app = express()
app.use(express.json())
app.use(express.urlencoded({extended : false}))
app.use(express.static(path.join(__dirname, 'public')))
// app.use(express.static(path.join(__dirname, 'views')))

// app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'hbs')
hbs.registerPartials(path.join(__dirname, 'views'))

app.use('/users/register', registerroute)
app.get('/', (req, res)=>{
    res.render('layout')
})

app.listen(3000, _=> console.log('Server Started'))